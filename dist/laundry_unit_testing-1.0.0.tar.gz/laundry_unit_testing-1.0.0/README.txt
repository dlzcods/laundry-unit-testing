# `laundry unit testing`

The `laundry unit testing` is a simple unit testing example to understand the basics of unit testing in Python.